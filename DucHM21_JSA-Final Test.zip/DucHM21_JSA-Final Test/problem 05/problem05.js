function makeDigitZero(N)
{
    var dp = Array(N + 1).fill(1000000000);
    dp[0] = 0;
    for (var i = 0; i <= N; i++) {
        for (var j =0; j< i.toString().length; j++)
        {
            dp[i] = Math.min(dp[i],
                        dp[i - (i.toString()[j] - '0')]
                            + 1);
        }
    }
    return dp[N];
}
console.log(makeDigitZero(27)); //5
