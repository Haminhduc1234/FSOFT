function getData(url, cb) {
  var xhr = new XMLHttpRequest();

  xhr.onreadystatechange = function () {
    if (xhr.readyState == XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        cb(undefined, JSON.parse(xhr.responseText));
      } else {
        cb(new Error(xhr.statusText));
      }
    }
  };

  xhr.open('GET', url, true);
  xhr.send();
}

const USERS = 'https://jsonplaceholder.typicode.com/users';
const ALBUMS = 'https://jsonplaceholder.typicode.com/albums';
const PHOTOS = 'https://jsonplaceholder.typicode.com/photos';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.handleChooseUser = this.handleChooseUser.bind(this);
    this.state = { users: [], albums: [] };
  }

  componentDidMount() {
    // YOUR CODE HERE
    // Problem 01
    getData(USERS, (err, userData) => {
      this.setState({ users: userData })
    })


    // ------------------------------------
    // PROBLEM01 BY PROBLEM03 USING PROMISE
    // const promise = fetch(USERS);
    // promise
    //     .then(response => {
    //         return response.json();
    //     })
    //     .then(userData => {
    //         this.setState({users: userData})
    //     })
    //     .catch(err => {
    //         console.log(data);
    //     })


    // -------------------------------------
    // //PROBLEM01 BY PROBLEM04 USING ASYNC/AWAIT
    // async componentDidMount() {
    //   try {
    //     const response = await fetch(USERS);
    //     const userData = await response.json();
    //     this.setState({ users: userData });
    //   } catch (error) {
    //     console.log(error);
    //   }
    // }
  }

  // YOUR CODE HERE
  async handleChooseUser(event) {
    // Id of user when select
    var userId = event.target.value;
    // Problem 2
    getData(ALBUMS + '?userId=' + userId, (err, albumsByUser) => {
      if(!err) {
        albumsByUser.forEach(ele => {
          getData(PHOTOS + '?albumId=' + ele.id ,(err, photos) => {
            if(!err) {
              ele.photos = photos;
              console.log(photos)
              this.setState({ albums: albumsByUser })
            }
          })

        });
      }
    } )




    // ------------------------------------
    // PROBLEM02 BY PROBLEM03 USING PROMISE
    // const promise = fetch(ALBUMS + '?userId=' + userId)
    // promise
    //   .then(response => response.json())
    //   .then(albumsByUser => {
    //     albumsByUser.forEach(ele => {
    //       fetch(PHOTOS + '?albumId=' + ele.id)
    //         .then(response2 => response2.json())
    //         .then(photo => {
    //           ele.photos = photo;
    //           this.setState({ albums: albumsByUser })
    //         })
    //     });
    //   })

    // ----------------------------------
    //PROBLEM02 BY PROBLEM04 USING ASYNC/AWAIT
    // try {
    //   const response = await fetch(`${ALBUMS}?userId=${userId}`);
    //   const albumsByUser = await response.json();
    //   albumsByUser.forEach(async ele => {
    //     console.log(ele);
    //     const responsePhotos = await fetch(`${PHOTOS}?albumId=${ele.id}`)
    //     const photos = await responsePhotos.json();
    //     ele.photos = photos;
    //     this.setState({ albums: albumsByUser })
    //   })
    // }
    // catch (error) {
    //   console.log(error);
    // }

  }



  renderAlbums() {
    const { albums } = this.state;

    if (!albums) {
      return <h1>Loading albums...</h1>;
    }

    return albums.map(function (album, index) {
      return (
        <div key={'album' + index} className="row">
          <h4 className="col-12 pt-4">Album {album.id}</h4>
          {album.photos ? (
            album.photos.map(function (photo, index) {
              return (
                <div
                  key={'photo' + index}
                  className="card col-3 pt-2"
                  style={{ width: '18rem;' }}
                >
                  <img
                    class="card-img-top"
                    src={photo.thumbnailUrl}
                    alt={photo.title}
                  />
                  <div class="card-body">
                    <p class="card-text">
                      <strong>Photo {photo.id}:</strong> {photo.title}
                    </p>
                  </div>
                </div>
              );
            })
          ) : (
            <h2>Loading photos...</h2>
          )}
        </div>
      );
    });
  }

  render() {
    if (!this.state.users) {
      return <h1>Loading...</h1>;
    }

    return (
      <div className="container-fluid" >
        <h1>Photo Galery</h1>
        <select class="custom-select" onChange={this.handleChooseUser}>
          <option selected>Choose user...</option>
          {this.state.users.map((user, index) => {
            return (
              <option key={'option' + index} value={user.id}>
                {user.name}
              </option>
            );
          })}
        </select>
        <div className="albums-wrapper">{this.renderAlbums()}</div>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.querySelector('#root'));
