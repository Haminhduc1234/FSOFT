(function () {
  var app = angular.module('myApp', []);

  app.controller('demoCtrl', ['$scope', DemoController]);

  function getDataPromise(url) {
    return new Promise(function (resolve, reject) {
      $.get(url, function (data, status) {
        if (status === 'success') {
          resolve(data);
        }
        reject(new Error('Error while getting ' + url));
      });
    });
  }

  const USER_API = 'https://jsonplaceholder.typicode.com/users';
  const POST_API = 'https://jsonplaceholder.typicode.com/posts?userId=';

  function DemoController($scope) {
    // Your Code Here
    // Callback-style
    // $.get(USER_API, function (users) {
    //   console.log(users);
    //   let count = 0;
    //   users.forEach(function (user) {
    //     $.get(POST_API + user.id, function (posts) {
    //       user.posts = posts;
    //       count++;

    //       if (count === users.length) {
    //         $scope.$apply(function () {
    //           console.log('display UI');
    //           $scope.users = users;
    //         });
    //       }
    //     });
    //   });
    // });

    // let allUsers;
    // getDataPromise(USER_API)
    //   .then(function (users) {
    //     allUsers = users;
    //     return Promise.all(
    //       users
    //         .map((user) => user.id) // [0, 1, .. 10]
    //         .map((id) => getDataPromise(POST_API + id))
    //     ); // [Promise<p0>, ....Promise<p10>]
    //     // Promise<[p0, ...p10]>
    //   })
    //   .then(function (allPosts) {
    //     allPosts.forEach(function (item, index) {
    //       allUsers[index].posts = item;
    //     });

    //     $scope.$apply(function () {
    //       console.log('display UI');
    //       $scope.users = allUsers;
    //     });
    //   });
  }
})();
