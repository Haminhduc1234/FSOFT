function empty(o) {
    o = null;
}
var x = [];
empty(x);
console.log(x); //[] -> Khong the gan lai null -> arr (object)