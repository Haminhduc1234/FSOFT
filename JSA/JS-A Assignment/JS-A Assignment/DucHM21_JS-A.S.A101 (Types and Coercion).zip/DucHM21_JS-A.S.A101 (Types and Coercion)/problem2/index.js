function swap(a,b) {
    var tmp = a;
    a = b;
    b = tmp;
}
var x = 1;
var y = 2;
swap(x,y);
console.log(x); //1 => x, y la cac tham tri nen khi truyen vao ham khong phai la ban than cac bien x,y hay,  tham chieu den chung 