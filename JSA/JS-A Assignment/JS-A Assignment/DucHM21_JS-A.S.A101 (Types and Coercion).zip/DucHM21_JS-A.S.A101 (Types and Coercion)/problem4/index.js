function mul(a , b) {
    return String(a*b);
}
console.log( typeof mul(12345678910111213,89));

console.log(mul(1234567891011121314,89));